
HELPER FILES FOR POPULAR DEBUGGERS

imgui.gdb
    GDB: disable stepping into trivial functions.
    (read comments inside file for details)

imgui.natstepfilter
    Visual Studio Debugger: disable stepping into trivial functions.
    (read comments inside file for details)

imgui.natvis
    Visual Studio Debugger: describe Dear ImGui types for better display.
    With this, types like ImVector<> will be displayed nicely in the debugger.
    (read comments inside file for details)

